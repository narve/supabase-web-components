create view open_snoke_requests(snoke_request_id, created_at, full_name, year_of_birth, county) as
SELECT req.id AS snoke_request_id,
       req.created_at,
       req.full_name,
       req.year_of_birth,
       req.county
FROM snoke_request req
         LEFT JOIN snoke_response resp ON req.id = resp.snoke_request_id
WHERE resp.id IS NULL
  AND req.created_by <> auth.uid()
ORDER BY (random());

alter table open_snoke_requests
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on open_snoke_requests to anon;

grant delete, insert, references, select, trigger, truncate, update on open_snoke_requests to authenticated;

grant delete, insert, references, select, trigger, truncate, update on open_snoke_requests to service_role;

