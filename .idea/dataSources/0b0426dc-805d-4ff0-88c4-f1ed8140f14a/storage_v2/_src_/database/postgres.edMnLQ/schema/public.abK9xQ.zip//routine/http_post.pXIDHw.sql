create function http_post(uri character varying, content character varying, content_type character varying) returns http_response
    language sql
as
$$ SELECT public.http(('POST', $1, NULL, $3, $2)::public.http_request) $$;

alter function http_post(varchar, varchar, varchar) owner to supabase_admin;

grant execute on function http_post(varchar, varchar, varchar) to postgres;

grant execute on function http_post(varchar, varchar, varchar) to anon;

grant execute on function http_post(varchar, varchar, varchar) to authenticated;

grant execute on function http_post(varchar, varchar, varchar) to service_role;

