create procedure login_as(IN user_email text)
    language plpgsql
as
$$
    begin
        perform set_config('request.jwt.claims',
                   (select jsonb_build_object('sub', id::text)::text
                    from auth.users
                    where auth.users.email = user_email),
                   true);
        set role authenticated;
--         return (select id from auth.users where email = user_email);
    end;
    $$;

alter procedure login_as(text) owner to postgres;

grant execute on procedure login_as(text) to anon;

grant execute on procedure login_as(text) to authenticated;

grant execute on procedure login_as(text) to service_role;

