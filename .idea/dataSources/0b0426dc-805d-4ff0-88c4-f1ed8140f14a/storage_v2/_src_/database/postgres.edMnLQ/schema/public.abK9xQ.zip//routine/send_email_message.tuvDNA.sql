create function send_email_message(message jsonb) returns json
    language plpgsql
as
$$
DECLARE
-- variable declaration
--     email_provider text := 'mailgun'; -- 'mailgun', 'sendgrid', 'sendinblue', 'mailjet', 'mailersend'
    email_provider text := 'mailersend'; -- 'mailgun', 'sendgrid', 'sendinblue', 'mailjet', 'mailersend'
    retval         json;
    messageid      text;
BEGIN


    IF message -> 'text_body' IS NULL AND message -> 'html_body' IS NULL THEN
        RAISE 'message.text_body or message.html_body is required';
    END IF;

    IF message -> 'text_body' IS NULL THEN
        select message || jsonb_build_object('text_body', message ->> 'html_body') into message;
    END IF;

    IF message -> 'html_body' IS NULL THEN
        select message || jsonb_build_object('html_body', message ->> 'text_body') into message;
    END IF;

    IF message -> 'recipient' IS NULL THEN RAISE 'message.recipient is required'; END IF;
    IF message -> 'sender' IS NULL THEN RAISE 'message.sender is required'; END IF;
    IF message -> 'subject' IS NULL THEN RAISE 'message.subject is required'; END IF;

    IF message -> 'messageid' IS NULL AND (SELECT to_regclass('public.messages')) IS NOT NULL THEN
-- messages table exists, so save this message in the messages table
        INSERT INTO public.messages(recipient, sender, cc, bcc, subject, text_body, html_body, status, log)
        VALUES (message -> 'recipient', message -> 'sender', message -> 'cc', message -> 'bcc', message -> 'subject',
                message -> 'text_body', message -> 'html_body', 'ready', '[]'::jsonb)
        RETURNING id INTO messageid;
        select message || jsonb_build_object('messageid', messageid) into message;
    END IF;

    EXECUTE 'SELECT send_email_' || email_provider || '($1)' INTO retval USING message;
    -- SELECT send_email_mailgun(message) INTO retval;
-- SELECT send_email_sendgrid(message) INTO retval;

    RETURN retval;
END;
$$;

alter function send_email_message(jsonb) owner to postgres;

grant execute on function send_email_message(jsonb) to anon;

grant execute on function send_email_message(jsonb) to authenticated;

grant execute on function send_email_message(jsonb) to service_role;

