create view my_open_snoke_requests
            (id, full_name, county, year_of_birth, created_by, modified_by, created_at, modified_at) as
SELECT req.id,
       req.full_name,
       req.county,
       req.year_of_birth,
       req.created_by,
       req.modified_by,
       req.created_at,
       req.modified_at
FROM snoke_request req
         LEFT JOIN snoke_response resp ON req.id = resp.snoke_request_id
WHERE resp.id IS NULL
ORDER BY (random());

alter table my_open_snoke_requests
    owner to postgres;

grant delete, insert, references, select, trigger, truncate, update on my_open_snoke_requests to anon;

grant delete, insert, references, select, trigger, truncate, update on my_open_snoke_requests to authenticated;

grant delete, insert, references, select, trigger, truncate, update on my_open_snoke_requests to service_role;

