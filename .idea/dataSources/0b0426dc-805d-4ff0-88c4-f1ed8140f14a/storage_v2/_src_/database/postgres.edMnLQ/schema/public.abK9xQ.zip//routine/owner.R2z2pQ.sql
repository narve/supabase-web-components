create function owner(location) returns SETOF users
    stable
    rows 1
    language sql
as
$$
  select id, email from public.users where id = $1.owner_id
$$;

alter function owner(location) owner to postgres;

grant execute on function owner(location) to anon;

grant execute on function owner(location) to authenticated;

grant execute on function owner(location) to service_role;

