create function http_get(uri character varying) returns http_response
    language sql
as
$$ SELECT public.http(('GET', $1, NULL, NULL, NULL)::public.http_request) $$;

alter function http_get(varchar) owner to supabase_admin;

grant execute on function http_get(varchar) to postgres;

grant execute on function http_get(varchar) to anon;

grant execute on function http_get(varchar) to authenticated;

grant execute on function http_get(varchar) to service_role;

