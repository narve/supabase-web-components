create function http_header(field character varying, value character varying) returns http_header
    language sql
as
$$ SELECT $1, $2 $$;

alter function http_header(varchar, varchar) owner to supabase_admin;

grant execute on function http_header(varchar, varchar) to postgres;

grant execute on function http_header(varchar, varchar) to anon;

grant execute on function http_header(varchar, varchar) to authenticated;

grant execute on function http_header(varchar, varchar) to service_role;

