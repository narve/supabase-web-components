create function http_get(uri character varying, data jsonb) returns http_response
    language sql
as
$$
        SELECT public.http(('GET', $1 || '?' || urlencode($2), NULL, NULL, NULL)::public.http_request)
    $$;

alter function http_get(varchar, jsonb) owner to supabase_admin;

grant execute on function http_get(varchar, jsonb) to postgres;

grant execute on function http_get(varchar, jsonb) to anon;

grant execute on function http_get(varchar, jsonb) to authenticated;

grant execute on function http_get(varchar, jsonb) to service_role;

