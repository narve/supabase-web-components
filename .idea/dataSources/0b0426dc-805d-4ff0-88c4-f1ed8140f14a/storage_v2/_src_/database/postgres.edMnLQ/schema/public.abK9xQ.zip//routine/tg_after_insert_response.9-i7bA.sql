create function tg_after_insert_response() returns trigger
    language plpgsql
as
$$
    begin
        insert into outgoing_email (snoke_request_id, recipient, subject, body)
        select new.id, u.email, 'SNOKING utført', 'Du har fått et snoke-svar. Logg inn for å se det.'
        from auth.users u
        where u.id = new.created_by;
    end;
    $$;

alter function tg_after_insert_response() owner to postgres;

grant execute on function tg_after_insert_response() to anon;

grant execute on function tg_after_insert_response() to authenticated;

grant execute on function tg_after_insert_response() to service_role;

