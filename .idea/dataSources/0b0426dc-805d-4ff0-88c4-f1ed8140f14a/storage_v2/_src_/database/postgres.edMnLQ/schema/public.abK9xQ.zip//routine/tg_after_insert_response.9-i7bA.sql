create function tg_after_insert_response() returns trigger
    security definer
    language plpgsql
as
$$
    begin
        insert into outgoing_email (snoke_request_id, recipient, subject, body)
        select new.id, 
               req_creator.email, 
               'SNOKING utført', 
               'Du har fått et snoke-svar. Logg inn for å se det: https://snok.netflify.app'
        from auth.users req_creator inner join snoke_request req on req.created_by = req_creator.id
        where req.id = new.snoke_request_id;
        return new;
    end;
    $$;

alter function tg_after_insert_response() owner to postgres;

grant execute on function tg_after_insert_response() to anon;

grant execute on function tg_after_insert_response() to authenticated;

grant execute on function tg_after_insert_response() to service_role;

