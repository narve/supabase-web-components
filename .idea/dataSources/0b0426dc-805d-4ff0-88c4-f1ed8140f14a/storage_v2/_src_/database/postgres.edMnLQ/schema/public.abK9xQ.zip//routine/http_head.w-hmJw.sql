create function http_head(uri character varying) returns http_response
    language sql
as
$$ SELECT public.http(('HEAD', $1, NULL, NULL, NULL)::public.http_request) $$;

alter function http_head(varchar) owner to supabase_admin;

grant execute on function http_head(varchar) to postgres;

grant execute on function http_head(varchar) to anon;

grant execute on function http_head(varchar) to authenticated;

grant execute on function http_head(varchar) to service_role;

