create function http_post(uri character varying, data jsonb) returns http_response
    language sql
as
$$
        SELECT public.http(('POST', $1, NULL, 'application/x-www-form-urlencoded', urlencode($2))::public.http_request)
    $$;

alter function http_post(varchar, jsonb) owner to supabase_admin;

grant execute on function http_post(varchar, jsonb) to postgres;

grant execute on function http_post(varchar, jsonb) to anon;

grant execute on function http_post(varchar, jsonb) to authenticated;

grant execute on function http_post(varchar, jsonb) to service_role;

