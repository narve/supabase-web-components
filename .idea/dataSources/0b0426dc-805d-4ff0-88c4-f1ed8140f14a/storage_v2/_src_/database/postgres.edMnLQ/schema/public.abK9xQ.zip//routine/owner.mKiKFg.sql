create function owner(todo) returns SETOF users
    stable
    rows 1
    language sql
as
$$
  select id, email from public.users where id = $1.owner_id
$$;

alter function owner(todo) owner to postgres;

grant execute on function owner(todo) to anon;

grant execute on function owner(todo) to authenticated;

grant execute on function owner(todo) to service_role;

