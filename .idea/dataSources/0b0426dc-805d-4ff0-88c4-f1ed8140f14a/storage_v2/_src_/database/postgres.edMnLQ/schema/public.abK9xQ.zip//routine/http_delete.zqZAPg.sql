create function http_delete(uri character varying) returns http_response
    language sql
as
$$ SELECT public.http(('DELETE', $1, NULL, NULL, NULL)::public.http_request) $$;

alter function http_delete(varchar) owner to supabase_admin;

grant execute on function http_delete(varchar) to postgres;

grant execute on function http_delete(varchar) to anon;

grant execute on function http_delete(varchar) to authenticated;

grant execute on function http_delete(varchar) to service_role;

