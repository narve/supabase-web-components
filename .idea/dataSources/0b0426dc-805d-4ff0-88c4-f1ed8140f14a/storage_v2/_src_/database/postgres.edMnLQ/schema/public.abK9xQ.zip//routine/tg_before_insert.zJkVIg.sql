create function tg_before_insert() returns trigger
    language plpgsql
as
$$
    begin
    new.created_by = auth.uid();
    new.modified_by = auth.uid();
    new.created_at = now();
    new.modified_at = now();
    return new;
    end;
    $$;

alter function tg_before_insert() owner to postgres;

grant execute on function tg_before_insert() to anon;

grant execute on function tg_before_insert() to authenticated;

grant execute on function tg_before_insert() to service_role;

